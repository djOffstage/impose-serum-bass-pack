IMPOSE — Serum 2 Bass Pack
24 analog / tech-house / reese / acid / 808 / growl patches
Inspired by AU_MT_bass_memories_imposing (Organics / AC hum1)

============================================================
WHAT IS IN THIS ZIP
============================================================
/Original/   Reference Serum 1 .fxp — loads in Serum 2
/Recipes/    One text sheet per patch (rebuild in ~2 minutes)
/JSON/       Machine-readable recipes
/OneShots/   C2 WAV previews rendered from the IMPOSE engine

============================================================
SERUM 2 — HOW TO INSTALL
============================================================
1. ORIGINAL REFERENCE (.fxp)
   Drag AU_MTF_bass_synth_memories_imposing.fxp onto Serum 2,
   or Menu → Open Preset and choose the .fxp.
   Serum 2 converts legacy Serum 1 presets on load.

2. REBUILD THE 24 IMPOSE PATCHES
   Open each file in /Recipes/. Init a Serum 2 patch and match
   OSC A/B/C, Noise, Filter, Envelopes, LFO, FX, Macros.
   Factory wavetables only (Analog / Juno Saw, Basic Shapes,
   I Saw The Sine, PWM, Dirty Saw, Organics / AC hum1).
   Save as .SerumPreset into:
     Documents/Xfer/Serum 2 Presets/User/IMPOSE/
   Then Menu → Rescan folders on disk.

3. ONE-SHOTS
   Drop /OneShots/ into FL Studio, Ableton, or a sampler if you
   want the sound now and the synth later.

============================================================
WHY THERE ARE NO .SerumPreset BINARIES
============================================================
Serum 2's native format is compressed CBOR. Files generated
without Serum will crash the plugin. These recipes use factory
wavetables and exact knob values so a rebuild is safe.

The included .fxp is the real reference patch you supplied
(AU_MT_bass_memories_imposing) and is the one file that loads
natively today.

============================================================
PLAYING NOTES
============================================================
Range     C1–C3 (sub lives at C1; C2 reads on laptop speakers)
Mono      recommended on HUM / SUB / 808
Wobbles   hold a note, lock LFO to host
Macros    1 Drive   2 Width   3 Dark   4 Texture / Hum

Pack  IMPOSE 1.0
